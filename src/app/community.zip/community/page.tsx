"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import PostForm from "@/components/community/PostForm";
import { useAuthStore } from "@/store/useAuthStore";

export default function WritePostPage() {
  const router = useRouter();
  const { isLoggedIn } = useAuthStore();

  // persist 스토어는 클라이언트에서만 복원되므로, mount 이후에 로그인 여부를 판단
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (mounted && !isLoggedIn) router.replace("/auth/login");
  }, [mounted, isLoggedIn, router]);

  if (!mounted || !isLoggedIn) return null;

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-2xl bg-bg-primary px-6 py-5">
        <p className="text-[11px] font-medium uppercase tracking-wider text-text-secondary">
          Community
        </p>
        <h1 className="mt-1 text-[20px] font-bold text-text-primary">글쓰기</h1>
      </div>
      <PostForm mode="create" />
    </div>
  );
}
