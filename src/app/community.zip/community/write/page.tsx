"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  CATEGORY_LABEL,
  SEARCH_TYPE_LABEL,
  SORT_LABEL,
  getPosts,
  type PageResponse,
  type PostCategory,
  type PostResponse,
  type PostSearchType,
  type PostSort,
} from "@/lib/api/community";
import { BADGE_STYLE, timeAgo } from "@/components/community/communityUtils";

const PAGE_SIZE = 20;

const CATEGORY_TABS: { value: PostCategory | ""; label: string }[] = [
  { value: "", label: "전체" },
  { value: "FREE", label: "자유" },
  { value: "ANALYSIS", label: "분석" },
];

const SORTS: PostSort[] = ["createdAt", "likeCount", "viewCount"];
const SEARCH_TYPES: PostSearchType[] = ["TITLE_CONTENT", "TITLE", "AUTHOR"];

// ── URL 쿼리 파싱 (잘못된 값은 기본값으로) ─────────────────────────────
function parseCategory(v: string | null): PostCategory | "" {
  return v === "FREE" || v === "ANALYSIS" ? v : "";
}
function parseSearchType(v: string | null): PostSearchType {
  return SEARCH_TYPES.includes(v as PostSearchType)
    ? (v as PostSearchType)
    : "TITLE_CONTENT";
}
function parseSort(v: string | null): PostSort {
  return SORTS.includes(v as PostSort) ? (v as PostSort) : "createdAt";
}
function parsePage(v: string | null): number {
  return Math.max(1, parseInt(v ?? "1", 10) || 1);
}

// ── 페이지네이션 ─────────────────────────────────────────────────────
function Pagination({
  page,
  totalPages,
  onChange,
}: {
  page: number;
  totalPages: number;
  onChange: (page: number) => void;
}) {
  if (totalPages <= 1) return null;

  const windowSize = 5;
  const start = Math.floor((page - 1) / windowSize) * windowSize + 1;
  const end = Math.min(start + windowSize - 1, totalPages);
  const pages = Array.from({ length: end - start + 1 }, (_, i) => start + i);

  const btn =
    "min-w-[32px] rounded-lg px-2.5 py-1.5 text-[12px] transition-colors";

  return (
    <div className="flex items-center justify-center gap-1 py-4">
      <button
        onClick={() => onChange(page - 1)}
        disabled={page <= 1}
        className={`${btn} text-text-secondary hover:bg-bg-secondary disabled:opacity-30`}
      >
        이전
      </button>
      {pages.map((p) => (
        <button
          key={p}
          onClick={() => onChange(p)}
          className={`${btn} ${
            p === page
              ? "bg-accent font-semibold text-white"
              : "text-text-secondary hover:bg-bg-secondary"
          }`}
        >
          {p}
        </button>
      ))}
      <button
        onClick={() => onChange(page + 1)}
        disabled={page >= totalPages}
        className={`${btn} text-text-secondary hover:bg-bg-secondary disabled:opacity-30`}
      >
        다음
      </button>
    </div>
  );
}

// ── 목록 본체 ────────────────────────────────────────────────────────
function CommunityList() {
  const router = useRouter();
  const searchParams = useSearchParams();

  // 필터 상태는 전부 URL 이 source of truth → 상세에서 뒤로가기 해도 유지됨
  const category = parseCategory(searchParams.get("category"));
  const keyword = searchParams.get("keyword") ?? "";
  const searchType = parseSearchType(searchParams.get("searchType"));
  const sort = parseSort(searchParams.get("sort"));
  const page = parsePage(searchParams.get("page"));

  const [keywordInput, setKeywordInput] = useState(keyword);
  const [typeInput, setTypeInput] = useState<PostSearchType>(searchType);

  const [data, setData] = useState<PageResponse<PostResponse> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  // URL 이 바뀌면(뒤로가기 포함) 검색 입력창도 맞춰준다
  useEffect(() => {
    setKeywordInput(keyword);
    setTypeInput(searchType);
  }, [keyword, searchType]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(false);

    getPosts({
      page: page - 1,
      size: PAGE_SIZE,
      category: category || undefined,
      keyword: keyword || undefined,
      searchType,
      sort,
      direction: "desc",
    })
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch(() => {
        if (!cancelled) setError(true);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [category, keyword, searchType, sort, page]);

  /** 쿼리 일부만 바꿔서 URL 갱신 (값이 비어 있으면 파라미터 제거) */
  const pushQuery = (patch: Record<string, string | undefined>) => {
    const params = new URLSearchParams(searchParams.toString());
    Object.entries(patch).forEach(([k, v]) => {
      if (v) params.set(k, v);
      else params.delete(k);
    });
    const qs = params.toString();
    router.replace(qs ? `/community?${qs}` : "/community", { scroll: false });
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = keywordInput.trim();
    pushQuery({
      keyword: trimmed || undefined,
      searchType: trimmed && typeInput !== "TITLE_CONTENT" ? typeInput : undefined,
      page: undefined,
    });
  };

  const handleResetSearch = () => {
    setKeywordInput("");
    pushQuery({ keyword: undefined, searchType: undefined, page: undefined });
  };

  const posts = data?.content ?? [];

  return (
    <div className="flex flex-col gap-4">
      {/* 헤더 */}
      <div className="flex items-center justify-between rounded-2xl bg-bg-primary px-6 py-5">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-wider text-text-secondary">
            Community
          </p>
          <h1 className="mt-1 text-[20px] font-bold text-text-primary">
            커뮤니티
          </h1>
        </div>
        <Link
          href="/community/write"
          className="rounded-lg bg-accent px-4 py-2 text-[13px] font-semibold text-white transition-opacity hover:opacity-90"
        >
          글쓰기
        </Link>
      </div>

      <div className="overflow-hidden rounded-2xl bg-bg-primary">
        {/* 카테고리 탭 + 정렬 */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border-tertiary px-5 py-3">
          <div className="flex gap-1">
            {CATEGORY_TABS.map((tab) => (
              <button
                key={tab.value}
                onClick={() =>
                  pushQuery({ category: tab.value || undefined, page: undefined })
                }
                className={`rounded-lg px-3 py-1.5 text-[13px] transition-colors ${
                  category === tab.value
                    ? "bg-accent font-semibold text-white"
                    : "text-text-secondary hover:bg-bg-secondary"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            {SORTS.map((s) => (
              <button
                key={s}
                onClick={() =>
                  pushQuery({
                    sort: s === "createdAt" ? undefined : s,
                    page: undefined,
                  })
                }
                className={`text-[12px] transition-colors ${
                  sort === s
                    ? "font-semibold text-text-primary"
                    : "text-text-secondary hover:text-text-primary"
                }`}
              >
                {SORT_LABEL[s]}
              </button>
            ))}
          </div>
        </div>

        {/* 검색 */}
        <form
          onSubmit={handleSearch}
          className="flex gap-2 border-b border-border-tertiary px-5 py-3"
        >
          <select
            value={typeInput}
            onChange={(e) => setTypeInput(e.target.value as PostSearchType)}
            className="shrink-0 rounded-lg border border-border-tertiary bg-bg-secondary px-2.5 py-2 text-[12px] text-text-primary outline-none focus:border-accent"
          >
            {SEARCH_TYPES.map((t) => (
              <option key={t} value={t}>
                {SEARCH_TYPE_LABEL[t]}
              </option>
            ))}
          </select>
          <input
            type="text"
            value={keywordInput}
            onChange={(e) => setKeywordInput(e.target.value)}
            placeholder="검색어를 입력하세요"
            className="min-w-0 flex-1 rounded-lg border border-border-tertiary bg-bg-secondary px-3.5 py-2 text-[13px] text-text-primary outline-none placeholder:text-text-secondary/50 focus:border-accent focus:ring-1 focus:ring-accent/20 transition-colors"
          />
          <button
            type="submit"
            className="shrink-0 rounded-lg bg-navy px-4 text-[12px] font-medium text-white transition-opacity hover:opacity-90"
          >
            검색
          </button>
        </form>

        {keyword && (
          <div className="flex items-center justify-between border-b border-border-tertiary bg-bg-secondary px-5 py-2 text-[12px] text-text-secondary">
            <span>
              “<span className="font-medium text-text-primary">{keyword}</span>”
              검색 결과 {data?.totalElements ?? 0}건
            </span>
            <button
              onClick={handleResetSearch}
              className="hover:text-text-primary"
            >
              검색 초기화
            </button>
          </div>
        )}

        {/* 목록 */}
        <div className={loading && data ? "opacity-60 transition-opacity" : ""}>
          {error ? (
            <div className="py-16 text-center text-[13px] text-text-secondary">
              게시글을 불러오지 못했어요.
            </div>
          ) : loading && !data ? (
            <div className="space-y-4 px-5 py-5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className="h-10 animate-pulse rounded bg-bg-tertiary"
                />
              ))}
            </div>
          ) : posts.length === 0 ? (
            <div className="py-16 text-center text-[13px] text-text-secondary">
              {keyword ? "검색 결과가 없어요." : "아직 등록된 게시글이 없어요."}
            </div>
          ) : (
            posts.map((post) => (
              <Link
                key={post.id}
                href={`/community/${post.id}`}
                className="flex items-center gap-3 border-b border-border-tertiary px-5 py-3.5 transition-colors last:border-none hover:bg-bg-secondary"
              >
                <span
                  className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-medium ${
                    BADGE_STYLE[post.category] ??
                    "bg-bg-tertiary text-text-secondary"
                  }`}
                >
                  {CATEGORY_LABEL[post.category] ?? post.category}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate text-[14px] font-medium text-text-primary">
                      {post.title}
                    </span>
                    {post.commentCount > 0 && (
                      <span className="shrink-0 text-[12px] font-semibold text-accent">
                        [{post.commentCount}]
                      </span>
                    )}
                  </div>
                  <div className="mt-0.5 text-[11px] text-text-secondary">
                    {post.nickname} · {timeAgo(post.createdAt)}
                  </div>
                </div>
                <div className="flex shrink-0 gap-3 text-[11px] tabular-nums text-text-secondary">
                  <span>조회 {post.viewCount}</span>
                  <span>좋아요 {post.likeCount}</span>
                </div>
              </Link>
            ))
          )}
        </div>

        <Pagination
          page={page}
          totalPages={data?.totalPages ?? 0}
          onChange={(p) =>
            pushQuery({ page: p <= 1 ? undefined : String(p) })
          }
        />
      </div>
    </div>
  );
}

// useSearchParams 는 Suspense 경계가 필요 (없으면 production build 에서 에러)
export default function CommunityPage() {
  return (
    <Suspense fallback={null}>
      <CommunityList />
    </Suspense>
  );
}
