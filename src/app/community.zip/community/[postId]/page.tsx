"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import axios from "axios";
import {
  CATEGORY_LABEL,
  deletePost,
  getPost,
  togglePostLike,
  type PostResponse,
} from "@/lib/api/community";
import CommentSection from "@/components/community/CommentSection";
import {
  BADGE_STYLE,
  formatDate,
  getErrorMessage,
} from "@/components/community/communityUtils";
import { useAuthStore } from "@/store/useAuthStore";

type Status = "loading" | "ok" | "notfound" | "error";

export default function PostDetailPage() {
  const params = useParams<{ postId: string }>();
  const postId = Number(params.postId);
  const router = useRouter();
  const { isLoggedIn, userId } = useAuthStore();

  const [post, setPost] = useState<PostResponse | null>(null);
  const [status, setStatus] = useState<Status>("loading");
  const [likePending, setLikePending] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    if (Number.isNaN(postId)) {
      setStatus("notfound");
      return;
    }

    let cancelled = false;
    setStatus("loading");

    getPost(postId)
      .then((p) => {
        if (cancelled) return;
        setPost(p);
        setStatus("ok");
      })
      .catch((err) => {
        if (cancelled) return;
        setStatus(
          axios.isAxiosError(err) && err.response?.status === 404
            ? "notfound"
            : "error"
        );
      });

    return () => {
      cancelled = true;
    };
  }, [postId]);

  // 댓글을 쓰거나 지울 때 헤더의 댓글 수도 같이 맞춰준다
  const handleCommentCount = useCallback((count: number) => {
    setPost((p) => (p ? { ...p, commentCount: count } : p));
  }, []);

  const handleLike = async () => {
    if (!post || likePending) return;
    if (!isLoggedIn) {
      router.push("/auth/login");
      return;
    }

    setLikePending(true);
    setActionError(null);
    try {
      const res = await togglePostLike(post.id);
      setPost((p) =>
        p ? { ...p, liked: res.liked, likeCount: res.likeCount } : p
      );
    } catch (err) {
      setActionError(getErrorMessage(err, "좋아요 처리에 실패했어요."));
    } finally {
      setLikePending(false);
    }
  };

  const handleDelete = async () => {
    if (!post || deleting) return;
    if (!window.confirm("정말 삭제할까요? 댓글도 함께 삭제돼요.")) return;

    setDeleting(true);
    setActionError(null);
    try {
      await deletePost(post.id);
      router.replace("/community");
    } catch (err) {
      setActionError(getErrorMessage(err, "삭제에 실패했어요."));
      setDeleting(false);
    }
  };

  if (status === "loading") {
    return (
      <div className="flex flex-col gap-4">
        <div className="h-64 animate-pulse rounded-2xl bg-bg-primary" />
      </div>
    );
  }

  if (status !== "ok" || !post) {
    return (
      <div className="rounded-2xl bg-bg-primary py-20 text-center text-[13px] text-text-secondary">
        <p>
          {status === "notfound"
            ? "게시글을 찾을 수 없어요. 삭제되었을 수 있어요."
            : "게시글을 불러오지 못했어요."}
        </p>
        <Link
          href="/community"
          className="mt-3 inline-block text-accent hover:underline"
        >
          목록으로
        </Link>
      </div>
    );
  }

  const isOwner = isLoggedIn && userId === post.userId;

  return (
    <div className="flex flex-col gap-4">
      <Link
        href="/community"
        className="self-start text-[12px] text-text-secondary hover:text-text-primary"
      >
        ← 목록으로
      </Link>

      <article className="rounded-2xl bg-bg-primary px-6 py-6">
        {/* 헤더 */}
        <div className="flex items-start gap-2">
          <span
            className={`mt-1 shrink-0 rounded px-1.5 py-0.5 text-[10px] font-medium ${
              BADGE_STYLE[post.category] ?? "bg-bg-tertiary text-text-secondary"
            }`}
          >
            {CATEGORY_LABEL[post.category] ?? post.category}
          </span>
          <h1 className="min-w-0 break-words text-[20px] font-bold leading-snug text-text-primary">
            {post.title}
          </h1>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-b border-border-tertiary pb-4">
          <div className="text-[12px] text-text-secondary">
            <span className="font-medium text-text-primary">{post.nickname}</span>
            {" · "}
            {formatDate(post.createdAt)}
            {" · "}조회 {post.viewCount}
            {" · "}댓글 {post.commentCount}
          </div>

          {isOwner && (
            <div className="flex gap-3 text-[12px]">
              <Link
                href={`/community/${post.id}/edit`}
                className="text-text-secondary hover:text-text-primary"
              >
                수정
              </Link>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="text-text-secondary hover:text-red-500 disabled:opacity-50"
              >
                {deleting ? "삭제 중..." : "삭제"}
              </button>
            </div>
          )}
        </div>

        {/* 본문 (React 가 이스케이프하므로 줄바꿈만 살려서 출력) */}
        <div className="whitespace-pre-wrap break-words py-6 text-[14px] leading-relaxed text-text-primary">
          {post.content}
        </div>

        {post.relatedPlayerId && (
          <Link
            href={`/players/${post.relatedPlayerId}`}
            className="inline-block rounded-lg bg-bg-secondary px-3 py-1.5 text-[12px] text-text-secondary transition-colors hover:text-accent"
          >
            관련 선수 보기 →
          </Link>
        )}

        {/* 좋아요 */}
        <div className="mt-4 flex flex-col items-center gap-2 border-t border-border-tertiary pt-6">
          <button
            onClick={handleLike}
            disabled={likePending}
            className={`rounded-full px-6 py-2.5 text-[13px] font-semibold transition-colors disabled:opacity-60 ${
              post.liked
                ? "bg-accent text-white"
                : "border border-border-tertiary bg-bg-secondary text-text-secondary hover:border-accent hover:text-accent"
            }`}
          >
            ♥ 좋아요 {post.likeCount}
          </button>
          {actionError && (
            <p className="text-[12px] text-red-500">{actionError}</p>
          )}
        </div>
      </article>

      <CommentSection postId={post.id} onCountChange={handleCommentCount} />
    </div>
  );
}
